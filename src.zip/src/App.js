import React, { useState, useEffect } from 'react';
import axios from 'axios';

function App() {
  const [cadastro, setCadastro] = useState({ nome: '', email: '', senha: '', tipo: 'estudante' });
  const [login, setLogin] = useState({ email: '', senha: '' });
  const [modoAutenticacao, setModoAutenticacao] = useState(null);
  const [mensagem, setMensagem] = useState('');
  const [usuario, setUsuario] = useState(null);
  const [grupos, setGrupos] = useState([]);
  const [filtro, setFiltro] = useState('');
  const [novoGrupo, setNovoGrupo] = useState({ nome: '', disciplina: '', horario: '' });
  const [mostrarFormularioGrupo, setMostrarFormularioGrupo] = useState(false);
  const [grupoSelecionado, setGrupoSelecionado] = useState(null);
  const [mensagens, setMensagens] = useState([]);
  const [mensagemInput, setMensagemInput] = useState('');
  const [editandoPerfil, setEditandoPerfil] = useState(false);
  const [perfil, setPerfil] = useState({ nome: '', email: '', senha: '' });
  const [grupoEmEdicao, setGrupoEmEdicao] = useState(null);
  const [gruposDoUsuario, setGruposDoUsuario] = useState([]);


  const handleCadastroChange = e => setCadastro({ ...cadastro, [e.target.name]: e.target.value });
  const handleLoginChange = e => setLogin({ ...login, [e.target.name]: e.target.value });
  const handleNovoGrupoChange = e => setNovoGrupo({ ...novoGrupo, [e.target.name]: e.target.value });

  const cadastrarUsuario = e => {
    e.preventDefault();
    axios.post("http://192.168.0.249:3001/usuarios", cadastro)
      .then(res => setMensagem("Cadastro realizado com sucesso!"))
      .catch(err => setMensagem("Erro ao cadastrar."));
  };

  const realizarLogin = e => {
    e.preventDefault();
    axios.post("http://192.168.0.249:3001/login", login)
      .then(res => {
        setUsuario(res.data);
        setMensagem(`Bem-vindo, ${res.data.nome}`);
      })
      .catch(err => setMensagem("Login inválido."));
  };

  const carregarGrupos = () => {
    axios.get("http://192.168.0.249:3001/grupos")
      .then(res => setGrupos(res.data))
      .catch(err => console.error("Erro ao carregar grupos", err));
  };

  useEffect(() => {
    if (usuario) carregarGrupos();
  }, [usuario]);

  useEffect(() => {
    if (usuario) {
      axios.get(`http://192.168.0.249:3001/meus-grupos/${usuario.id}`)
        .then(res => setGruposDoUsuario(res.data))
        .catch(err => console.error("Erro ao carregar grupos do usuário", err));
    }
  }, [usuario]);


  const criarGrupo = () => {
  if (!usuario || usuario.tipo !== 'admin') return;

  const { nome, disciplina, horario } = novoGrupo;
  if (!nome.trim() || !disciplina.trim() || !horario.trim()) {
    setMensagem("Preencha todos os campos do grupo.");
    return;
  }

  axios.post("http://192.168.0.249:3001/grupos", { ...novoGrupo, criador_id: usuario.id })
    .then(() => {
      setMensagem("Grupo criado!");
      setNovoGrupo({ nome: '', disciplina: '', horario: '' });
      setMostrarFormularioGrupo(false);
      carregarGrupos();
    })
    .catch(() => setMensagem("Erro ao criar grupo."));
};


  const atualizarGrupo = (id, dados) => {
    axios.put(`http://192.168.0.249:3001/grupos/${id}`, dados)
      .then(() => {
        setMensagem("Grupo atualizado com sucesso.");
        carregarGrupos();
      })
      .catch(() => setMensagem("Erro ao atualizar grupo."));
  };


  const excluirGrupo = id => {
    if (window.confirm("Tem certeza que deseja excluir este grupo?")) {
      axios.delete(`http://192.168.0.249:3001/grupos/${id}`, { data: { usuario_id: usuario.id } })
        .then(() => carregarGrupos())
        .catch(() => setMensagem("Erro ao excluir grupo."));
    }
  };

  const entrarNoGrupo = grupo => {
    axios.post("http://192.168.0.249:3001/participar", {
      usuario_id: usuario.id,
      grupo_id: grupo.id
    }).then(() => {
      setGrupoSelecionado(grupo);

      // Carrega as mensagens do grupo
      axios.get(`http://192.168.0.249:3001/mensagens/${grupo.id}`)
        .then(res => setMensagens(res.data));

      // Atualiza os grupos do perfil
      axios.get(`http://192.168.0.249:3001/meus-grupos/${usuario.id}`)
        .then(res => setGruposDoUsuario(res.data));
    }).catch(() => {
      setMensagem("Erro ao entrar no grupo ou você já está nele.");
    });
  };



  const sairDoGrupo = (grupo_id) => {
    axios.delete("http://192.168.0.249:3001/sair-do-grupo", {
      data: {
        usuario_id: usuario.id,
        grupo_id: grupo_id
      }
    }).then(() => {
      setMensagem("Você saiu do grupo.");
      setGruposDoUsuario(gruposDoUsuario.filter(g => g.id !== grupo_id));
    }).catch(() => {
      setMensagem("Erro ao sair do grupo.");
    });
  };


  const enviarMensagem = () => {
    if (!usuario || !mensagemInput || !grupoSelecionado) return;
    axios.post("http://192.168.0.249:3001/mensagens", {
      conteudo: mensagemInput,
      remetente_id: usuario.id,
      grupo_id: grupoSelecionado.id
    }).then(() => {
      setMensagemInput('');
      entrarNoGrupo(grupoSelecionado);
    });
  };

  useEffect(() => {
    if (usuario) {
      axios.get(`http://192.168.0.249:3001/meus-grupos/${usuario.id}`)
        .then(res => setGruposDoUsuario(res.data))
        .catch(err => console.error("Erro ao carregar grupos do usuário", err));
    }
  }, [usuario]);


  const gruposFiltrados = grupos.filter(g =>
    g.nome.toLowerCase().includes(filtro.toLowerCase()) ||
    g.disciplina.toLowerCase().includes(filtro.toLowerCase())
  );

  return (
    <div className="container">
      <h1>StudyMatch - Cliente</h1>

      {!usuario && (
        <>
          <div className="perfil-opcoes">
            <button onClick={() => setModoAutenticacao(modoAutenticacao === 'cadastro' ? null : 'cadastro')}>
              {modoAutenticacao === 'cadastro' ? 'Fechar Cadastro' : 'Cadastrar'}
            </button>
            <button onClick={() => setModoAutenticacao(modoAutenticacao === 'login' ? null : 'login')}>
              {modoAutenticacao === 'login' ? 'Fechar Login' : 'Login'}
            </button>
          </div>

          {modoAutenticacao === 'cadastro' && (
            <>
              <h2>Cadastro</h2>
              <form onSubmit={cadastrarUsuario}>
                <input name="nome" placeholder="Nome" onChange={handleCadastroChange} required />
                <input name="email" placeholder="Email" onChange={handleCadastroChange} required />
                <input name="senha" type="password" placeholder="Senha" onChange={handleCadastroChange} required />
                <select name="tipo" value={cadastro.tipo} onChange={handleCadastroChange}>
                  <option value="estudante">Estudante</option>
                  <option value="admin">Administrador</option>
                </select>
                <button type="submit">Cadastrar</button>
              </form>
            </>
          )}

          {modoAutenticacao === 'login' && (
            <>
              <h2>Login</h2>
              <form onSubmit={realizarLogin}>
                <input name="email" placeholder="Email" onChange={handleLoginChange} required />
                <input name="senha" type="password" placeholder="Senha" onChange={handleLoginChange} required />
                <button type="submit">Entrar</button>
              </form>
            </>
          )}
        </>
      )}


      {usuario && (
        <>
          <h2>Bem-vindo, {usuario.nome}</h2>

        <div className="perfil-opcoes">
          <button onClick={() => setEditandoPerfil(!editandoPerfil)}>
            {editandoPerfil ? 'Fechar Perfil' : 'Perfil'}
          </button>
          <button onClick={() => {
            setUsuario(null);
            setGrupoSelecionado(null);
            setMensagem('Sessão encerrada.');
          }}>Sair</button>
        </div>


        {editandoPerfil && (
          <div className="editar-form">
            <h3>Meu Perfil</h3>

            <label>Nome</label>
            <input
              type="text"
              value={perfil.nome}
              onChange={e => setPerfil({ ...perfil, nome: e.target.value })}
            />

            <label>Email</label>
            <input
              type="email"
              value={perfil.email}
              onChange={e => setPerfil({ ...perfil, email: e.target.value })}
            />

            <label>Senha</label>
            <input
              type="password"
              value={perfil.senha}
              onChange={e => setPerfil({ ...perfil, senha: e.target.value })}
            />

            <div className="grupo-botoes">
              <button onClick={() => {
                const campos = {};
                if (perfil.nome && perfil.nome !== usuario.nome) campos.nome = perfil.nome;
                if (perfil.email && perfil.email !== usuario.email) campos.email = perfil.email;
                if (perfil.senha && perfil.senha !== usuario.senha) campos.senha = perfil.senha;

                if (Object.keys(campos).length === 0) {
                  setMensagem("Nenhuma alteração feita.");
                  return;
                }

                axios.put(`http://192.168.0.249:3001/perfil/${usuario.id}`, campos)
                  .then(() => {
                    setMensagem("Perfil atualizado com sucesso!");
                    setUsuario({ ...usuario, ...campos });
                    setEditandoPerfil(false);
                  })
                  .catch(() => setMensagem("Erro ao atualizar perfil."));
              }}>
                Salvar Alterações
              </button>


              <button onClick={() => setEditandoPerfil(false)}>Fechar Perfil</button>
            </div>

            <h4 style={{ marginTop: '2rem' }}>Meus Grupos</h4>
            <ul>
              {gruposDoUsuario.length === 0 ? (
                <li>Você ainda não participa de nenhum grupo.</li>
              ) : (
                gruposDoUsuario.map(grupo => (
                  <li key={grupo.id}>
                    <strong>{grupo.nome}</strong> - {grupo.disciplina} ({grupo.horario})
                    <button
                      onClick={() => sairDoGrupo(grupo.id)}
                      style={{ marginTop: '0.5rem', backgroundColor: '#dc3545' }}
                    >
                      Sair do grupo
                    </button>
                  </li>
                ))
              )}
            </ul>

          </div>
        )}


  {usuario.tipo === 'admin' && (
    <>
      <button
        onClick={() => {
          setMostrarFormularioGrupo(!mostrarFormularioGrupo);
          if (!mostrarFormularioGrupo) {
            setNovoGrupo({ nome: '', disciplina: '', horario: '' }); // limpa ao abrir
          }
        }}
      >
        {mostrarFormularioGrupo ? 'Cancelar' : 'Criar Novo Grupo'}
      </button>
      {mostrarFormularioGrupo && (
        <div style={{ marginTop: '1rem' }}>
          <input
            name="nome"
            placeholder="Nome do grupo"
            value={novoGrupo.nome}
            onChange={handleNovoGrupoChange}
          />
          <input
            name="disciplina"
            placeholder="Disciplina"
            value={novoGrupo.disciplina}
            onChange={handleNovoGrupoChange}
          />
          <input
            name="horario"
            placeholder="Horário"
            value={novoGrupo.horario}
            onChange={handleNovoGrupoChange}
          />
          <button onClick={criarGrupo}>Criar Grupo</button>
        </div>
      )}
    </>
  )}


  <h3>Buscar Grupos</h3>
  <input
    type="text"
    placeholder="Buscar por nome ou disciplina"
    value={filtro}
    onChange={(e) => setFiltro(e.target.value)}
  />

  <h3>Grupos Disponíveis</h3>

  <ul>
    {gruposFiltrados.map(grupo => (
      <li key={grupo.id}>
        <strong>{grupo.nome}</strong> - {grupo.disciplina} ({grupo.horario})

        <div className="grupo-botoes">
          <button onClick={() => entrarNoGrupo(grupo)}>Entrar</button>

          {usuario.tipo === 'admin' && usuario.id === grupo.criador_id && (
            <>
              <button onClick={() => setGrupoEmEdicao(grupo.id)}>Editar</button>
              <button onClick={() => excluirGrupo(grupo.id)}>Excluir</button>
            </>
          )}
        </div>

        {grupoEmEdicao === grupo.id && (
          <div>
            <input placeholder="Novo nome" onChange={e => grupo.novoNome = e.target.value} />
            <input placeholder="Nova disciplina" onChange={e => grupo.novaDisciplina = e.target.value} />
            <input placeholder="Novo horário" onChange={e => grupo.novoHorario = e.target.value} />
            <div className="grupo-botoes">
              <button onClick={() => {
                if (grupo.novoNome && grupo.novaDisciplina && grupo.novoHorario) {
                  atualizarGrupo(grupo.id, {
                    nome: grupo.novoNome,
                    disciplina: grupo.novaDisciplina,
                    horario: grupo.novoHorario,
                    usuario_id: usuario.id
                  });
                  setGrupoEmEdicao(null);
                } else {
                  setMensagem("Preencha todos os campos para editar o grupo.");
                }
              }}>Salvar Edição</button>

              <button onClick={() => setGrupoEmEdicao(null)}>Cancelar Edição</button>
            </div>
          </div>
        )}


      </li>
    ))}
  </ul>


  {grupoSelecionado && (
    <>
      <h3>Chat - {grupoSelecionado.nome}</h3>
      <div className="chat-box">
        {mensagens.map((m, i) => (
          <div key={i} className={`message${m.remetente_id === usuario.id ? ' own' : ''}`}>
            {m.conteudo}
          </div>
        ))}
      </div>
      <input
        placeholder="Digite sua mensagem"
        value={mensagemInput}
        onChange={e => setMensagemInput(e.target.value)}
      />
      <button onClick={enviarMensagem}>Enviar</button>
    </>
  )}
  </>
  )}

      {mensagem && <p>{mensagem}</p>}
    </div>
  );
}

export default App;
