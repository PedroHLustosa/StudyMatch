const express = require("express");
const app = express();
const mysql = require("mysql2");
const cors = require("cors");

const db = mysql.createPool({
  host: "localhost",
  user: "root",
  password: "",
  port: 3306,
  database: "studymatch",
});

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// 🔐 Cadastro de Usuário
app.post("/usuarios", (req, res) => {
  const { nome, email, senha, tipo } = req.body;
  const sql = "INSERT INTO usuarios (nome, email, senha, tipo) VALUES (?, ?, ?, ?)";
  db.query(sql, [nome, email, senha, tipo], (err, result) => {
    if (err) return res.status(500).json({ error: err });
    res.json({ message: "Usuário cadastrado", id: result.insertId });
  });
});

// 🔐 Login
app.post("/login", (req, res) => {
  const { email, senha } = req.body;
  const sql = "SELECT * FROM usuarios WHERE email = ? AND senha = ?";
  db.query(sql, [email, senha], (err, result) => {
    if (err) return res.status(500).json({ error: err });
    if (result.length > 0) return res.json(result[0]);
    return res.status(401).json({ error: "Credenciais inválidas" });
  });
});

// 👤 Atualizar perfil
app.put("/perfil/:id", (req, res) => {
  const id = req.params.id;
  const { nome, email, senha } = req.body;

  console.log("Requisição recebida para atualizar perfil:");
  console.log("ID:", id);
  console.log("Nome:", nome);
  console.log("Email:", email);
  console.log("Senha:", senha);

  if (!nome && !email && !senha) {
    console.log("Nenhum campo recebido.");
    return res.status(400).json({ error: "Nenhum campo foi enviado." });
  }

  const campos = [];
  const valores = [];

  if (nome) {
    campos.push("nome = ?");
    valores.push(nome);
  }
  if (email) {
    campos.push("email = ?");
    valores.push(email);
  }
  if (senha) {
    campos.push("senha = ?");
    valores.push(senha);
  }

  valores.push(id);

  const sql = `UPDATE usuarios SET ${campos.join(', ')} WHERE id = ?`;

  console.log("SQL gerado:", sql);
  console.log("Valores:", valores);

  db.query(sql, valores, (err, result) => {
    if (err) {
      console.error("Erro MySQL:", err);
      return res.status(500).json({ error: err.message });
    }

    if (result.affectedRows === 0) {
      console.log("Nenhum usuário encontrado com o ID:", id);
      return res.status(404).json({ error: "Usuário não encontrado." });
    }

    console.log("Usuário atualizado com sucesso.");
    res.json({ message: "Perfil atualizado com sucesso!" });
  });
});


// 📚 Criar grupo
app.post("/grupos", (req, res) => {
  const { nome, disciplina, horario, criador_id } = req.body;

  // 1. Buscar o usuário para validar se é admin
  const checkUserSql = "SELECT tipo FROM usuarios WHERE id = ?";
  db.query(checkUserSql, [criador_id], (err, result) => {
    if (err) return res.status(500).json({ error: err });
    if (result.length === 0 || result[0].tipo !== 'admin') {
      return res.status(403).json({ error: "Apenas administradores podem criar grupos." });
    }

    // 2. Validar campos obrigatórios
    if (!nome || !disciplina || !horario) {
      return res.status(400).json({ error: "Todos os campos são obrigatórios." });
    }

    // 3. Inserir grupo
    const sql = "INSERT INTO grupos (nome, disciplina, horario, criador_id) VALUES (?, ?, ?, ?)";
    db.query(sql, [nome, disciplina, horario, criador_id], (err, result) => {
      if (err) return res.status(500).json({ error: err });
      res.json({ message: "Grupo criado com sucesso!", id: result.insertId });
    });
  });
});

// 📚 Listar grupos
app.get("/grupos", (req, res) => {
  const sql = "SELECT * FROM grupos";
  db.query(sql, (err, result) => {
    if (err) return res.status(500).json({ error: err });
    res.json(result);
  });
});

// 💬 Enviar mensagem
app.post("/mensagens", (req, res) => {
  const { conteudo, remetente_id, grupo_id } = req.body;
  const sql = "INSERT INTO mensagens (conteudo, remetente_id, grupo_id, data) VALUES (?, ?, ?, NOW())";
  db.query(sql, [conteudo, remetente_id, grupo_id], (err, result) => {
    if (err) return res.status(500).json({ error: err });
    res.json({ message: "Mensagem enviada", id: result.insertId });
  });
});

// 💬 Listar mensagens de um grupo
app.get("/mensagens/:grupo_id", (req, res) => {
  const grupo_id = req.params.grupo_id;
  const sql = "SELECT * FROM mensagens WHERE grupo_id = ? ORDER BY data ASC";
  db.query(sql, [grupo_id], (err, result) => {
    if (err) return res.status(500).json({ error: err });
    res.json(result);
  });
});

// Aualizar grupos
app.put("/grupos/:id", (req, res) => {
  const grupoId = req.params.id;
  const { nome, disciplina, horario, usuario_id } = req.body;

  // Verifica se o usuário é o criador do grupo
  const checkSql = "SELECT * FROM grupos WHERE id = ? AND criador_id = ?";
  db.query(checkSql, [grupoId, usuario_id], (err, results) => {
    if (err) return res.status(500).json({ error: err });
    if (results.length === 0) {
      return res.status(403).json({ error: "Acesso negado: você não é o criador deste grupo." });
    }

    // Atualiza o grupo
    const updateSql = "UPDATE grupos SET nome = ?, disciplina = ?, horario = ? WHERE id = ?";
    db.query(updateSql, [nome, disciplina, horario, grupoId], (err, result) => {
      if (err) return res.status(500).json({ error: err });
      res.json({ message: "Grupo atualizado com sucesso!" });
    });
  });
});


// Deletar grupos
app.delete("/grupos/:id", (req, res) => {
  const grupoId = req.params.id;
  const usuario_id = req.body.usuario_id;

  // Verifica se o usuário é o criador do grupo
  const checkSql = "SELECT * FROM grupos WHERE id = ? AND criador_id = ?";
  db.query(checkSql, [grupoId, usuario_id], (err, results) => {
    if (err) return res.status(500).json({ error: err });
    if (results.length === 0) {
      return res.status(403).json({ error: "Acesso negado: você não é o criador deste grupo." });
    }

    // Exclui o grupo
    const deleteSql = "DELETE FROM grupos WHERE id = ?";
    db.query(deleteSql, [grupoId], (err, result) => {
      if (err) return res.status(500).json({ error: err });
      res.json({ message: "Grupo excluído com sucesso!" });
    });
  });
});

//Mostra grupos do usuário
app.get("/meus-grupos/:usuarioId", (req, res) => {
  const usuarioId = req.params.usuarioId;

  const sql = `
    SELECT g.id, g.nome, g.disciplina, g.horario
    FROM grupos g
    JOIN participantes p ON g.id = p.grupo_id
    WHERE p.usuario_id = ?
  `;

  db.query(sql, [usuarioId], (err, results) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(results);
  });
});

//Sair do Grupo
app.delete("/sair-do-grupo", (req, res) => {
  const { usuario_id, grupo_id } = req.body;

  const sql = "DELETE FROM participantes WHERE usuario_id = ? AND grupo_id = ?";
  db.query(sql, [usuario_id, grupo_id], (err, result) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ message: "Você saiu do grupo com sucesso!" });
  });
});

//Participar de um grupo
app.post("/participar", (req, res) => {
  const { usuario_id, grupo_id } = req.body;

  const sql = "INSERT IGNORE INTO participantes (usuario_id, grupo_id) VALUES (?, ?)";
  db.query(sql, [usuario_id, grupo_id], (err, result) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ message: "Usuário adicionado ao grupo." });
  });
});


app.listen(3001, '0.0.0.0', () => {
  console.log("Servidor StudyMatch disponivel em rede!");
});
